import Loading from '../components/loading/Loading';

export default function LoadingPage() {
  return <Loading />;
}