import { init } from '@emailjs/browser';


init('VxrJ6XYUcPPeoA5pz');

export const emailConfig = {
    serviceId: 'service_91tesxn',    
    templateId: 'template_142vrso',  
    publicKey: 'VxrJ6XYUcPPeoA5pz'        
}; 